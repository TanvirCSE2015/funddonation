
<?php $__env->startSection('title'); ?>
<title>User List | Donation</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<style>
    .text-right{
        text-align: end;
    }
</style>
<?php $sum=0;
             
use lemonpatwari\BanglaNumber\NumberToBangla;
$numberToBangla = new NumberToBangla();

?>
<div class="container-xxl flex-grow-1 container-p-y">
    <!-- <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Forms/</span> Horizontal Layouts</h4> -->

        <!-- Basic Layout & Basic with Icons -->
    <div class="row">
        <!-- Basic Layout -->
        <div class="col-xxl">
            <div class="card mb-4">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h5 class="mb-0">ডোনার ফর্ম</h5>
                <small class="text-muted float-end">Default label</small>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.updateuser',$user->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label pt-0 text-right" for="basic-default-name">ডোনারের নাম <span class="text-danger" style="font-size: large;">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" value="<?php echo e($user->name); ?>" class="form-control" id="name" name="name" placeholder="নাম লিখুন" />
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label text-right" for="basic-default-name">ইমেইল</label>
                                <div class="col-sm-9">
                                    <input type="text" value="<?php echo e($user->email); ?>" class="form-control" id="email" name="email" placeholder="ইমেইল লিখুন" />
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label pt-0  text-right" for="basic-default-name">মোবাইল <span class="text-danger" style="font-size: large;">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" value="<?php echo e($user->phone); ?>" class="form-control" id="phone" name="phone" placeholder="মোবাইল নাম্বার লিখুন" />
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label pt-0  text-right" for="basic-default-name">শ্রেনী ও চাঁদা <span class="text-danger" style="font-size: large;">*</span>  </label>
                                <div class="col-sm-5">
                                    <select name="donar_type" id="donar_type" class="form-select">
                                        <option id="defaultSelect" value="">শ্রেনী নির্বাচন করুন</option>
                                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($row->type_name==$user->donar_type): ?>
                                        <option selected value="<?php echo e($row->type_name); ?>"><?php echo e($row->type_name); ?></option>
                                        <?php else: ?>
                                        <option value="<?php echo e($row->type_name); ?>"><?php echo e($row->type_name); ?></option>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                </div>
                                <div class="col-sm-4">
                                        <input type="text" value="<?php echo e($numberToBangla->bnNum($user->amount)); ?>" class="form-control" id="amount" name="amount" placeholder="চাঁদার পরিমান লিখুন">
                                    </div>
                                
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label text-right" for="basic-default-name">গ্রাম/মহল্লা/বাসা</label>
                                <div class="col-sm-9">
                                    <input type="text" value="<?php echo e($user->village); ?>" class="form-control" id="village" name="village" placeholder="গ্রাম/মহল্লা/বাসা নাম্বার লিখুন" />
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label text-right" for="basic-default-name">পোস্ট অফিস</label>
                                <div class="col-sm-9">
                                    <input type="text" value="<?php echo e($user->post); ?>" class="form-control" id="post" name="post" placeholder="ইমেইল লিখুন" />
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label text-right" for="basic-default-name">উপজেলা</label>
                                <div class="col-sm-9">
                                    <input type="text" value="<?php echo e($user->upzila); ?>" class="form-control" id="upzila" name="upzila" placeholder="উপজেলার নাম লিখুন" />
                                   
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label text-right" for="basic-default-name">জেলা</label>
                                <div class="col-sm-9">
                                    <input type="text" value="<?php echo e($user->district); ?>" class="form-control" id="district" name="district" placeholder="জেলার লিখুন" />
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="row justify-content-end">
                            <div class="col-sm-9">
                                <button type="submit" class="btn btn-primary">হালনাগাদ করুন</button>
                            </div>
                        </div>
                    </div>
                    
                </div>
                </form>
            </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\funddonation\resources\views/admin/user/edituser.blade.php ENDPATH**/ ?>