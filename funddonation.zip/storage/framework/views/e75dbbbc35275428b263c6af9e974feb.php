
<?php $__env->startSection('title'); ?>
<title>DailyDonation | Donation</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<?php 
             
    use lemonpatwari\BanglaNumber\NumberToBangla;
    $numberToBangla = new NumberToBangla();

?>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="card">
        <div class="row">
            <div class="col-sm-6">
                <h5 class="card-header">আজকের হাদিয়াঃ <?php echo e($numberToBangla->bnNum($sum)); ?> টাকা</h5>
            </div>
            <div class="col-sm-6 pull-right" style="padding:1rem 2rem;text-align:right;">
                <a href="<?php echo e(route('admin.newdonation')); ?>" class="btn btn-info text-white">নতুন হাদিয়া সংগ্রহ</a>
            </div>
        </div>
        <div class="table-responsive text-nowrap">
            <table class="table" id="table">
            <thead>
                <tr>
                <th>ছবি</th>
                <th>নাম</th>
                <th>মোবাইল</th>
                <th>ডোনারের ধরণ</th>
                <th>তারিখ</th>
                <th>হাদিয়া</th>                
                <!-- <th></th> -->
                </tr>
            </thead>
            <tbody class="table-border-bottom-0">
            
            <?php $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($row->donar_type!='admin'): ?>
            <tr>
            <td><a href="<?php echo e(route('admin.userdetails',$row->user_id)); ?>"><img class="w-px-40 h-auto rounded-circle" src="<?php echo e(asset('assets/img/avatars/donar.png')); ?>" alt="avatar" srcset=""></a></td>
                <td><?php echo e($row->name); ?></td>
                <td><?php echo e($row->phone); ?></td>
                <td><?php echo e($row->donar_type); ?></td>
                <td><?php echo e($row->donation_date); ?></td>
                
                <td><?php echo e($numberToBangla->bnNum($row->donation_amount)); ?></td>
                <!-- <td style="text-align:right;">
                    <div class="btn-group">
                        <a href="<?php echo e(route('admin.edituser',$row->id)); ?>" class="btn btn-success"><i class="bx bx-edit"></i></a>
                        <a href="<?php echo e(route('admin.deleteuser',$row->id)); ?>" class="btn btn-danger"><i class="bx bx-trash"></i></a>
                    </div>
                </td> -->
            </tr>
            
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
            </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\funddonation\resources\views/admin/donation/dailydonations.blade.php ENDPATH**/ ?>