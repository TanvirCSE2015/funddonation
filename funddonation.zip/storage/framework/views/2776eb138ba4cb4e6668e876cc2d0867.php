
<?php $__env->startSection('title'); ?>
<title>Donar Details | Donation</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<?php
use lemonpatwari\BanglaNumber\NumberToBangla;
$numberToBangla = new NumberToBangla();
$year1=2022;
?>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row pl-2 pr-2">
        <div class="col-sm-6">
            <h6 class="mb-1"><?php echo e($user->name); ?></h6>
            <h6 class="mb-1"><?php echo e($user['phone']); ?></h6>
            <h6><?php echo e($user['donar_type']); ?> দাতা</h6>
        </div>
        <div class="col-sm-6 text-right mr-2">
            <?php if($instalment>0): ?>
            <h6 class="mb-1">বাকিঃ <?php echo e($numberToBangla->bnNum($instalment)); ?></h6>
            <?php else: ?>
            <h6 class="mb-1">এডভান্সঃ <?php echo e($numberToBangla->bnNum(-($instalment))); ?></h6>
            <?php endif; ?>
            <h6 class="mb-1">চাঁদাঃ <?php echo e($numberToBangla->bnNum($user['amount'])); ?> টাকা</h6>
            <?php if($instalment>=0): ?>
            <h6 class="mb-1">সর্বমোটঃ <?php echo e($numberToBangla->bnNum($instalment * $user['amount'])); ?> টাকা</h6>
            <?php else: ?>
            <h6 class="mb-1">সর্বমোটঃ <?php echo e($numberToBangla->bnNum(-($instalment * $user['amount']))); ?> টাকা</h6>
            <?php endif; ?>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-8 pr-2 pl-2">
            <div class="card">
                <div class="row">
                    <div class="col-sm-8">
                        <h5 class="card-header">সর্বমোট হাদিয়াঃ <?php echo e($sum); ?> টাকা</h5>
                    </div>
                    <div class="col-sm-4 card-header">
                        <select name="year" id="year" class="form-select">
                            <?php for($i=10; $i>1;$i--): ?>
                            <?php if($year==($year1+10-$i)): ?>
                            <option value="<?php echo e(route('admin.userdetails',[$user->id,$year1+10-$i])); ?>" selected><?php echo e($year1+10-$i); ?></option>
                            <?php elseif(date('Y')==($year1+10-$i)): ?>
                            <option value="<?php echo e(route('admin.userdetails',[$user->id,$year1+10-$i])); ?>"><?php echo e($year1+10-$i); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e(route('admin.userdetails',[$user->id,$year1+10-$i])); ?>"><?php echo e($year1+10-$i); ?></option>
                            <?php endif; ?>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
                <div class="table-responsive text-nowrap">
                    <table class="table" id="table">
                        <thead>
                            <th>তারিখ</th>
                            <th>সময়</th>
                            <th>মাস</th>
                            <th>হাদিয়া</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->donation_date); ?></td>
                                <td><?php echo e($row->donation_time); ?></td>
                                <td><?php echo e($numberToBangla->bnMonth($row->month)); ?></td>
                                <td><?php echo e($numberToBangla->bnNum($row->donation_amount)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="card">
                <h4 class="card-header">আদায়কৃত</h4>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <th>মাস</th>
                            <th>চাঁদা</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ins_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ins): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php if($num==1): ?>
                                <td><?php echo e($numberToBangla->bnMonth($ins->ins_month)); ?></td>
                                <?php else: ?>
                                <?php 
                                $month_num=$ins->ins_month+$num;
                                $month=($month_num > 12 ? $month_num-12 : $month_num);
                                ?>
                                <td><?php echo e($numberToBangla->bnMonth($ins->ins_month)); ?>-<?php echo e($numberToBangla->bnMonth($month)); ?></td>
                                <?php endif; ?>
                                <td><?php echo e($numberToBangla->bnNum($ins->ins_amount)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function(){
        $('#year').on('change',function(){
            var href =$(this).val();
            window.location=href;
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\funddonation\resources\views/admin/user/userdetails.blade.php ENDPATH**/ ?>