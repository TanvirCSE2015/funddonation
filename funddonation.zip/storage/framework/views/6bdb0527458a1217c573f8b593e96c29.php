
<?php $__env->startSection('title'); ?>
<title>DailyDonation | Donation</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<?php 
    use lemonpatwari\BanglaNumber\NumberToBangla;
    $numberToBangla = new NumberToBangla();
   $year1=2022;
?>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="card">
        <div class="row">
            <div class="col-sm-6">
                <h5 class="card-header"><?php echo e($numberToBangla->bnMonth($month)); ?> মাসের হাদিয়াঃ <?php echo e(' '.$numberToBangla->bnNum($sum)); ?> টাকা</h5>
            </div>
            <div class="col-sm-3" style="padding:1rem 2rem;text-align:left;">
                <select name="year" id="year" class="form-select">
                    <?php for($i=10; $i>1;$i--): ?>
                    <?php if($year==($year1+10-$i)): ?>
                    <option value="<?php echo e(route('admin.permonthdonation',[date('m'),$year1+10-$i])); ?>" selected><?php echo e($year1+10-$i); ?></option>
                    <?php elseif(date('Y')==($year1+10-$i)): ?>
                    <option value="<?php echo e(route('admin.permonthdonation',[date('m'),$year1+10-$i])); ?>"><?php echo e($year1+10-$i); ?></option>
                    <?php else: ?>
                    <option value="<?php echo e(route('admin.permonthdonation',[1,$year1+10-$i])); ?>"><?php echo e($year1+10-$i); ?></option>
                    <?php endif; ?>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-sm-3 pull-right" style="padding:1rem 2rem;text-align:right;">
                
                <a href="<?php echo e(route('admin.newdonation')); ?>" class="btn btn-info text-white">নতুন হাদিয়া সংগ্রহ</a>
            </div>
        </div>
        
        <div class="table-responsive text-nowrap p-1">
            <div style="text-align:center">
                <div class="btn-group mb-2" role="group" aria-label="Basic example">
                    <a href="<?php echo e(route('admin.permonthdonation',1)); ?>" class="btn btn-secondary btn-padding <?php echo e($month ==1 ? 'btn-active' : ''); ?>">January</a>
                    <a href="<?php echo e(route('admin.permonthdonation',2)); ?>" class="btn btn-secondary btn-padding <?php echo e($month ==2 ? 'btn-active' : ''); ?>">February</a>
                    <a href="<?php echo e(route('admin.permonthdonation',3)); ?>" class="btn btn-secondary btn-padding <?php echo e($month ==3 ? 'btn-active' : ''); ?>">March</a>
                    <a href="<?php echo e(route('admin.permonthdonation',4)); ?>" class="btn btn-secondary btn-padding <?php echo e($month ==4 ? 'btn-active' : ''); ?>">April</a>
                    <a href="<?php echo e(route('admin.permonthdonation',5)); ?>" class="btn btn-secondary btn-padding <?php echo e($month ==5 ? 'btn-active' : ''); ?>">May</a>
                    <a href="<?php echo e(route('admin.permonthdonation',6)); ?>" class="btn btn-secondary btn-padding <?php echo e($month ==6 ? 'btn-active' : ''); ?>">June</a>
                    <a href="<?php echo e(route('admin.permonthdonation',7)); ?>" class="btn btn-secondary btn-padding <?php echo e($month ==7 ? 'btn-active' : ''); ?>">July</a>
                    <a href="<?php echo e(route('admin.permonthdonation',8)); ?>" class="btn btn-secondary btn-padding <?php echo e($month ==8 ? 'btn-active' : ''); ?>">August</a>
                    <a href="<?php echo e(route('admin.permonthdonation',9)); ?>" class="btn btn-secondary btn-padding <?php echo e($month ==9 ? 'btn-active' : ''); ?>">September</a>
                    <a href="<?php echo e(route('admin.permonthdonation',10)); ?>" class="btn btn-secondary btn-padding <?php echo e($month ==10 ? 'btn-active' : ''); ?>">October</a>
                    <a href="<?php echo e(route('admin.permonthdonation',11)); ?>" class="btn btn-secondary btn-padding <?php echo e($month ==11 ? 'btn-active' : ''); ?>">November</a>
                    <a href="<?php echo e(route('admin.permonthdonation',12)); ?>" class="btn btn-secondary btn-padding <?php echo e($month ==12 ? 'btn-active' : ''); ?>">December</a>
                </div>
            </div>
            <table class="table" id="table">
            <thead>
                <tr>
                <th>ছবি</th>
                <th>নাম</th>
                <th>মোবাইল</th>
                <th>ডোনারের ধরণ</th>
                <th>তারিখ</th>
                <th>হাদিয়া</th>                
                <!-- <th></th> -->
                </tr>
            </thead>
            <tbody class="table-border-bottom-0">
            
            <?php $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($row->donar_type!='admin'): ?>
            <tr>
            <td><a href="<?php echo e(route('admin.userdetails',$row->user_id)); ?>"><img class="w-px-40 h-auto rounded-circle" src="<?php echo e(asset('assets/img/avatars/donar.png')); ?>" alt="avatar" srcset=""></a></td>
                <td><?php echo e($row->name); ?></td>
                <td><?php echo e($row->phone); ?></td>
                <td><?php echo e($row->donar_type); ?></td>
                <td><?php echo e($row->donation_date); ?></td>
                
                <td><?php echo e($numberToBangla->bnNum($row->donation_amount)); ?></td>
                <!-- <td style="text-align:right;">
                    <div class="btn-group">
                        <a href="<?php echo e(route('admin.edituser',$row->id)); ?>" class="btn btn-success"><i class="bx bx-edit"></i></a>
                        <a href="<?php echo e(route('admin.deleteuser',$row->id)); ?>" class="btn btn-danger"><i class="bx bx-trash"></i></a>
                    </div>
                </td> -->
            </tr>
            
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
            </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function(){
        $('#year').on('change',function(){
            var href =$(this).val();
            window.location=href;
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\funddonation\resources\views/admin/donation/permonthdonation.blade.php ENDPATH**/ ?>