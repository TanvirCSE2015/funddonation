
<?php $__env->startSection('title'); ?>
<title>Create Event | Donation</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <!-- <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Forms/</span> Horizontal Layouts</h4> -->

        <!-- Basic Layout & Basic with Icons -->
    <div class="row">
        <!-- Basic Layout -->
        <div class="col-xxl">
            <div class="card mb-4">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h5 class="mb-0"> ইভেন্টের ফর্ম</h5>
                <small class="text-muted float-end">Default label</small>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.insertevent')); ?>" method="post" id="donation_form">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label pt-0 text-right" for="basic-default-name">ইভেন্টের নাম <span class="text-danger" style="font-size: large;">*</span></label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="event_title" name="event_title" placeholder="নাম লিখুন" />
                                    <?php $__errorArgs = ['event_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label text-right pt-0" for="basic-default-name" >তারিখ ও সময় <span class="text-danger" style="font-size: large;">*</span></label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="event_date" name="event_date" placeholder="তারিখ ও সময় লিখুন" />
                                    <?php $__errorArgs = ['event_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="row mb-3">
                            <label class="col-sm-1 col-form-label text-right pt-0" for="basic-default-name" style="min-width:8rem;">ইভেন্টের বর্নণা <span class="text-danger" style="font-size: large;">*</span></label>
                            <div class="col-sm-10">
                                <textarea name="event_description" class="form-control" id="event_description" cols="30" rows="5"></textarea>
                                <?php $__errorArgs = ['event_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    
                </div>
                <div class="row">
                    <div class="col-sm-1" style="min-width:8rem;">
                    
                   </div> 
                    <div class="col-sm-6">
                            <div class="col-sm-9">
                                <button type="submit" class="btn btn-primary">সংরক্ষন করুন</button>
                            </div>
                        
                    </div>  
                </div>
                </form>
            </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\funddonation\resources\views/admin/event/createevent.blade.php ENDPATH**/ ?>