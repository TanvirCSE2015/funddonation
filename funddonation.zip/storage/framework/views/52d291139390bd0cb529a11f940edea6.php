
<?php $__env->startSection('title'); ?>
<title>Event Details | Donation</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-sm-4">
            <h6>তারিখ ও সময়ঃ <?php echo e($event->event_date); ?></h6>
            <h6>ইভেন্টের নামঃ <?php echo e($event->event_title); ?></h6>
        </div>
        <div class="col-sm-8">
            <form action="">
            <div class="row">
                <div class="col-sm-12">
                    <div class="row mb-3">
                        
                        <label class="col-sm-1 col-form-label text-right pt-0" for="basic-default-name">বিবরন<span class="text-danger" style="font-size: large;">*</span></label>
                        <div class="col-sm-11">
                            <textarea name="event_description" disabled class="form-control" id="event_description" cols="30" rows="1"><?php echo e($event->event_description); ?></textarea>
                            <?php $__errorArgs = ['event_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                
            </div>
            </form>
        </div>
    </div>
    <div class="card">
        <div class="row">
            <div class="col-sm-6">
                <h5 class="card-header">ইভেন্ট মেম্বার</h5>
            </div>
            <div class="col-sm-6 pull-right" style="padding:1rem 2rem;text-align:right;">
                <a href="<?php echo e(route('admin.getdonars',[$event->event_id])); ?>" class="btn btn-info text-white" style="width:152px;" >নতুন যোগ করুন</a>
            </div>
        </div>
        <div class="table-responsive text-nowrap">
            <table class="table" id="table">
                <thead>
                    <th>ছবি</th>
                    <th>নাম</th>
                    <th>মোবাইল</th>
                    <th>নোট</th>
                    <th></th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><img class="w-px-40 h-auto rounded-circle" src="<?php echo e(asset('assets/img/avatars/donar.png')); ?>" alt="avatar" srcset=""></td>
                        <td><?php echo e($row->name); ?></td>
                        <td><?php echo e($row->phone); ?></td>
                        <?php if($row->ev_id=="" || $row->ev_id==null): ?>
                        <td></td>
                        <?php else: ?>
                        <td class=""> <span class="badge bg-warning"><?php echo e($row->note); ?></span></td>
                        <?php endif; ?>
                        <td>
                            <div class="btn-group">
                            <a href="#" id="<?php echo e($row->id); ?>" onclick="openModel(this.id)" class="btn btn-success"  data-bs-toggle="tooltip" data-bs-offset="0,4" data-bs-placement="bottom" data-bs-html="true" title="" data-bs-original-title="<i class='bx bxs-send'></i> <span>নোট লিখুন</span>"><i class='bx bx-notepad'></i></a>
                                <a href="<?php echo e(route('admin.removemember',$row->member_id)); ?>" class="btn btn-danger"data-bs-toggle="tooltip" data-bs-offset="0,4" data-bs-placement="bottom" data-bs-html="true" title="" data-bs-original-title=" <span>ডিলিট করুন </span>"><i class="bx bx-trash"></i></a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- Extra Large Modal -->
<div class="modal fade" id="noteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
        <div class="modal-header">
            
            <button
            type="button"
            class="btn-close"
            data-bs-dismiss="modal"
            aria-label="Close"
            ></button>
        </div>
        
        <div class="modal-body">
            <div class="row">
                <div class="col-sm-6">
                    <div id="user_info"></div>
                </div>
                <div class="col-sm-6">
                    <h6><?php echo e($event->event_title); ?></h6>
                    <h6><?php echo e($event->event_date); ?></h6>
                </div>
            </div>
            
            <div class="row g-2">
            <div class="col-sm-6 mb-0 border">
                <div class="table-responsive">
                    <table class="table" id="table_modal">
                        <thead>
                            <th>তারিখ</th>
                            <th>নোট</th>
                        </thead>
                        <tbody id="table_data">
                            
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-sm-6 mb-0 pl-2">
                <form action="<?php echo e(route('admin.inserteventnote')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_id" id="user_id" value="">
                    <input type="hidden" name="ev_id" id="ev_id" value="<?php echo e($event->event_id); ?>">
                    <input type="hidden" name="note_date" id="note_date" value="<?php echo e(date('d-m-Y')); ?>">
                    <input type="hidden" name="note_month" id="note_month" value="<?php echo e(date('m')); ?>">
                    <label for="dobExLarge" class="form-label">নোট লিখুন</label>
                    <textarea name="note" id="note" class="form-control" cols="30" rows="2"></textarea>
                    <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger" id="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="submit" class="btn btn-info text-white mt-2" value="সংরক্ষন করুন">
                </form>
            </div>
            </div>
        </div>
        
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function(){
        var error=document.getElementById('error').innerText;
    if(error=='অনুগ্রহপূর্বক নোট লিখুন'){
        document.getElementById('user_id').value="<?php echo e(Session::get('user_id')); ?>";
        $('#noteModal').modal('show');
    }
    })
    new DataTable('#modal_table');
    function openModel(id){
        document.getElementById('user_id').value=id;
        $.ajax({
            url:"<?php echo e(route('admin.notes')); ?>",
            type:'GET',
            data:{'id':id},
            success:function(output){
                
                if(output['code']==1){
                $('#user_info').html(output['user_html']);
                $('#table_modal').append(output['table_html']);
                }else{
                    $('#user_info').html(output['user_html']);
                    
                    $('#table_modal').html(output['table_html']);
                }
                //
            }
        })
        $('#noteModal').modal('show');
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\funddonation\resources\views/admin/event/eventdetails.blade.php ENDPATH**/ ?>