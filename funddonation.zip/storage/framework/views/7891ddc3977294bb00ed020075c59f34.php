
<?php $__env->startSection('title'); ?>
<title>Type List | Admin </title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<!-- Basic Bootstrap Table -->
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="card">
        <div class="row">
            <div class="col-sm-6">
                <h5 class="card-header">ডোনারের ধরণ</h5>
            </div>
            <div class="col-sm-6 pull-right" style="padding:1rem 2rem;text-align:right;">
                <a href="<?php echo e(route('admin.addtype')); ?>" class="btn btn-info text-white" style="width:152px;" >নতুন যোগ করুন</a>
            </div>
        </div>
        <div class="table-responsive text-nowrap">
            <table class="table">
            <thead>
                <tr>
                <th>সিরিয়াল</th>
                <th>নাম</th>
                <th></th>
                </tr>
            </thead>
            <tbody class="table-border-bottom-0">
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($row->type_id); ?></td>
                <td><?php echo e($row->type_name); ?></td>
                <td style="text-align:right;">
                    <div class="btn-group">
                        <a href="<?php echo e(route('admin.edittype',$row->type_id)); ?>" class="btn btn-success"><i class="bx bx-edit"></i></a>
                        <a href="<?php echo e(route('admin.deletetype',$row->type_id)); ?>" class="btn btn-danger"><i class="bx bx-trash"></i></a>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
        </div>
    </div>
</div>
    <!--/ Basic Bootstrap Table -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\funddonation\resources\views/admin/type/typelist.blade.php ENDPATH**/ ?>