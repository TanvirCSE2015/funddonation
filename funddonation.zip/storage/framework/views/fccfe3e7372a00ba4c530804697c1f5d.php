
<?php $__env->startSection('title'); ?>
<title>DailyDonation | Donation</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<?php 
    use lemonpatwari\BanglaNumber\NumberToBangla;
    $numberToBangla = new NumberToBangla();

?>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="card">
        <div class="row">
            <div class="col-sm-6">
                <h5 class="card-header">বাকি হাদিয়া</h5>
            </div>
            <div class="col-sm-6 pull-right" style="padding:1rem 2rem;text-align:right;">
                <a href="<?php echo e(route('admin.newdonation')); ?>" class="btn btn-info text-white">নতুন হাদিয়া সংগ্রহ</a>
            </div>
        </div>
        <div style="text-align: center;">
            
            <div class="btn-group" role="group" aria-label="Basic example">
                <a href="<?php echo e(route('admin.missingdonation',1)); ?>" class="btn btn-outline-secondary <?php echo e($num==1 ? 'secondary-active' : ''); ?>">মাসিক</a>
                <a href="<?php echo e(route('admin.missingdonation',3)); ?>" class="btn btn-outline-secondary <?php echo e($num==3 ? 'secondary-active' : ''); ?>">ত্রৈমাসিক</a>
                <a href="<?php echo e(route('admin.missingdonation',6)); ?>" class="btn btn-outline-secondary <?php echo e($num==6 ? 'secondary-active' : ''); ?>">অর্ধবার্ষিক</a>
                <a href="<?php echo e(route('admin.missingdonation',12)); ?>" class="btn btn-outline-secondary <?php echo e($num==12 ? 'secondary-active' : ''); ?>">বার্ষিক</a>
            </div>
                          
        </div>
        <div class="table-responsive text-nowrap p-1">
           
            <table class="table" id="table">
            <thead>
                <tr>
                <th>ছবি</th>
                <th>নাম</th>
                <th>মোবাইল</th>
                
                <th>সর্বশেষ</th>
                <th>হাদিয়া</th>
                <th>বাকি</th>
                <th>নোট</th>                 
                <th></th>
                </tr>
            </thead>
            <tbody class="table-border-bottom-0">
            
            <?php $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($row->donar_type!='admin'): ?>
            <tr>
                <td><img class="w-px-40 h-auto rounded-circle" src="<?php echo e(asset('assets/img/avatars/donar.png')); ?>" alt="avatar" srcset=""></td>
                <td><?php echo e($row->name); ?></td>
                <td><?php echo e($row->phone); ?></td>
                <td><?php echo e($row->last_date); ?></td>
                 <?php
                  $note=DB::table('notes')->where(['user_id'=>$row->id,'note_month'=>date('m')])
                  ->orderBy('note_id','DESC')->first();
                  ?>
                <td><?php echo e($numberToBangla->bnNum($row->amount)); ?></td>
                <td><?php echo e($numberToBangla->bnNum($row->num)); ?></td>
                <?php if($note!=null): ?>
                <td><?php echo e($note->note); ?></td>
                <?php else: ?>
                <td></td>
                <?php endif; ?>
                <td style="text-align:right;">
                    <div class="btn-group">
                        <a href="#" id="<?php echo e($row->id); ?>" onclick="openModel(this.id)" class="btn btn-success"  data-bs-toggle="tooltip" data-bs-offset="0,4" data-bs-placement="bottom" data-bs-html="true" title="" data-bs-original-title="<i class='bx bxs-send'></i> <span>নোট লিখুন</span>"><i class='bx bx-notepad'></i></a>
                    </div>
                </td>
            </tr>
            
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
            </tbody>
            </table>
        </div>
    </div>
</div>
 <!-- Extra Large Modal -->
 <div class="modal fade" id="noteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
        <div class="modal-header">
            
            <button
            type="button"
            class="btn-close"
            data-bs-dismiss="modal"
            aria-label="Close"
            ></button>
        </div>
        
        <div class="modal-body">
            <div id="user_info"></div>
            <div class="row g-2">
            <div class="col-sm-6 mb-0 border">
                <div class="table-responsive">
                    <table class="table" id="table_modal">
                        <thead>
                            <th>তারিখ</th>
                            <th>নোট</th>
                        </thead>
                        <tbody id="table_data">
                            
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-sm-6 mb-0 pl-2">
                <form action="<?php echo e(route('admin.insertnote')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_id" id="user_id" value="">
                    <input type="hidden" name="note_date" id="note_date" value="<?php echo e(date('d-m-Y')); ?>">
                    <input type="hidden" name="note_month" id="note_month" value="<?php echo e(date('m')); ?>">
                    <label for="dobExLarge" class="form-label">নোট লিখুন</label>
                    <textarea name="note" id="note" class="form-control" cols="30" rows="2"></textarea>
                    <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger" id="error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="submit" class="btn btn-info text-white mt-2" value="সংরক্ষন করুন">
                </form>
            </div>
            </div>
        </div>
        
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function(){
        var error=document.getElementById('error').innerText;
    if(error=='অনুগ্রহপূর্বক নোট লিখুন'){
        document.getElementById('user_id').value="<?php echo e(Session::get('user_id')); ?>";
        $('#noteModal').modal('show');
    }
    })
    new DataTable('#modal_table');
    function openModel(id){
        document.getElementById('user_id').value=id;
       
        $.ajax({
            url:"<?php echo e(route('admin.notes')); ?>",
            type:'GET',
            data:{'id':id},
            success:function(output){
                
                if(output['code']==1){
                $('#user_info').html(output['user_html']);
                }else{
                    $('#user_info').html(output['user_html']);
                    
                    $('#table_modal').html(output['table_html']);
                }
                //
            }
        })
        $('#noteModal').modal('show');
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\funddonation\resources\views/admin/donation/missingdonation.blade.php ENDPATH**/ ?>