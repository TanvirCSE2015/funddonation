
<?php $__env->startSection('title'); ?>
<title>User List | Donation</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<?php $sum=0;             
use lemonpatwari\BanglaNumber\NumberToBangla;
$numberToBangla = new NumberToBangla();
?>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="card">
        <div class="row">
            <div class="col-sm-6">
                <h5 class="card-header">ডোনারের তালিকা</h5>
            </div>
            <div class="col-sm-6 pull-right" style="padding:1rem 2rem;text-align:right;">
                <a href="<?php echo e(route('admin.adduser')); ?>" class="btn btn-info text-white" style="width:152px;" >নতুন যোগ করুন</a>
            </div>
        </div>
        <div class="table-responsive text-nowrap">
            <table class="table" id="table">
            <thead>
                <tr>
                <th>ছবি</th>
                <th>নাম</th>
                <th>মোবাইল</th>
                <th>ডোনারের ধরণ</th>
                <th>ঠিকানা</th>
                <th>চাঁদা</th>
                <th></th>
                </tr>
            </thead>
            <tbody class="table-border-bottom-0">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($row->donar_type!='admin'): ?>
            <tr>
                <td><a href="<?php echo e(route('admin.userdetails',$row->id)); ?>"><img class="w-px-40 h-auto rounded-circle" src="<?php echo e(asset('assets/img/avatars/donar.png')); ?>" alt="avatar" srcset=""></a></td>
                <td><?php echo e($row->name); ?></td>
                <td><?php echo e($row->phone); ?></td>
                <td><?php echo e($row->donar_type); ?></td>
                <td><?php echo e($row->village . ", " . $row->upzila); ?></td>
                <td><?php echo e($numberToBangla->bnNum($row->amount)); ?></td>
                <td style="text-align:right;">
                    <div class="btn-group">
                    <a href="<?php echo e(route('admin.adddonation',$row->id)); ?>" class="btn btn-info" data-bs-toggle="tooltip" data-bs-offset="0,4" data-bs-placement="bottom" data-bs-html="true" title="" data-bs-original-title="<span>পেমেন্ট করুন</span>"><i class='bx bxl-paypal'></i></a>
                        <a href="<?php echo e(route('admin.edituser',$row->id)); ?>" class="btn btn-success" data-bs-toggle="tooltip" data-bs-offset="0,4" data-bs-placement="bottom" data-bs-html="true" title="" data-bs-original-title="<span>আপডেট করুন</span>"><i class="bx bx-edit"></i></a>
                       
                        <a href="<?php echo e(route('admin.deleteuser',$row->id)); ?>" class="btn btn-danger" data-bs-toggle="tooltip" data-bs-offset="0,4" data-bs-placement="bottom" data-bs-html="true" title="" data-bs-original-title="<span>ডিলিট করুন</span>"><i class="bx bx-trash"></i></a>
                    </div>
                </td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\funddonation\resources\views/admin/user/userlist.blade.php ENDPATH**/ ?>