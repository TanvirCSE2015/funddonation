
<?php $__env->startSection('title'); ?>
<title>Edit Admin | Funddonation</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\funddonation\resources\views/admin/editadmin.blade.php ENDPATH**/ ?>